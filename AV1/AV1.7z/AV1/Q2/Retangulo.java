// Aluno: Rafael Fernandes das Neves
// Matrícula: 50015993
package AV1;
import java.util.Scanner;

public class Retangulo extends Quadrado {

    public void preencher() {
        System.out.println("======[PREENCHENDO RETANGULO]======");
        super.desenhar();
    }
}